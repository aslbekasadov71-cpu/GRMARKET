-- FAQAT eski (bitta do'kon) versiyasi o'rnatilgan va ichida kerakli ma'lumot YO'Q bo'lsa ishlating.
-- Hammasini o'chiradi! Keyin setup.sql ni ishga tushiring.
drop table if exists sale_items cascade;
drop table if exists sales cascade;
drop table if exists products cascade;
drop table if exists profiles cascade;
drop table if exists shops cascade;
drop trigger if exists on_signup on auth.users;
drop function if exists public.handle_new_user() cascade;
drop function if exists public.my_role() cascade;
drop function if exists public.make_sale(uuid, jsonb, timestamptz) cascade;
drop function if exists public.cancel_sale(bigint) cascade;
drop function if exists public.daily_totals(timestamptz) cascade;
drop function if exists public.top_products(timestamptz, timestamptz) cascade;
