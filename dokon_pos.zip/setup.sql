-- =====================================================================
-- DO'KON — ko'p do'konli baza (SaaS)
-- Supabase > SQL Editor > yangi so'rov > shuni to'liq qo'yib RUN bosing.
-- Qayta bajarilsa ham xavfsiz (ma'lumotni o'chirmaydi).
-- Har bir do'kon faqat o'z ma'lumotini ko'radi (RLS bilan himoyalangan).
-- =====================================================================

-- ---------- JADVALLAR ----------
create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  code text not null unique default upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)), -- xodimlar qo'shilishi uchun kod
  paid_until date not null default (current_date + 14),                                               -- 14 kunlik sinov
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  email text,
  shop_id uuid references public.shops on delete cascade,
  role text not null default 'none' check (role in ('none', 'owner', 'admin', 'pending'))
);

create table if not exists public.products (
  shop_id uuid not null references public.shops on delete cascade,
  barcode text not null,
  name text not null,
  price numeric not null default 0 check (price >= 0),
  stock numeric not null default 0,
  unit text not null default 'dona',
  primary key (shop_id, barcode)
);

create table if not exists public.sales (
  id bigint generated always as identity primary key,
  shop_id uuid not null references public.shops on delete cascade,
  client_id uuid,
  total numeric not null,
  status text not null default 'done' check (status in ('done', 'canceled')),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  canceled_at timestamptz,
  canceled_by uuid,
  unique (shop_id, client_id)
);
create index if not exists sales_shop_time on public.sales (shop_id, created_at desc);

create table if not exists public.sale_items (
  id bigint generated always as identity primary key,
  sale_id bigint not null references public.sales on delete cascade,
  shop_id uuid not null,
  barcode text,
  name text,
  qty numeric not null,
  price numeric not null
);
create index if not exists sale_items_sale on public.sale_items (sale_id);

-- ---------- YORDAMCHI FUNKSIYALAR ----------
create or replace function public.my_shop() returns uuid
language sql security definer stable set search_path = public as $$
  select shop_id from profiles where id = auth.uid()
$$;

create or replace function public.my_role() returns text
language sql security definer stable set search_path = public as $$
  select role from profiles where id = auth.uid()
$$;

-- Obuna faolmi (sinov yoki to'langan muddat tugamagan)
create or replace function public.shop_ok() returns boolean
language sql security definer stable set search_path = public as $$
  select coalesce((select s.paid_until >= current_date from shops s where s.id = my_shop()), false)
$$;

-- ---------- RO'YXATDAN O'TISH: profil avtomatik yaratiladi ----------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, email) values (new.id, new.email) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_signup on auth.users;
create trigger on_signup after insert on auth.users
for each row execute function public.handle_new_user();

-- ---------- XAVFSIZLIK (RLS) ----------
alter table public.shops enable row level security;
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;

-- eski (bir do'konli) qoidalar bo'lsa, olib tashlaymiz
drop policy if exists "profil o'qish" on public.profiles;
drop policy if exists "faqat egasi rol beradi" on public.profiles;
drop policy if exists "mahsulotlar" on public.products;
drop policy if exists "sotuv qo'shish" on public.sales;
drop policy if exists "sotuv o'qish" on public.sales;
drop policy if exists "sotuv tarkibi qo'shish" on public.sale_items;
drop policy if exists "sotuv tarkibi o'qish" on public.sale_items;

drop policy if exists p_profiles_sel on public.profiles;
create policy p_profiles_sel on public.profiles for select to authenticated
  using (id = auth.uid() or (my_role() = 'owner' and shop_id = my_shop()));

drop policy if exists p_products_sel on public.products;
create policy p_products_sel on public.products for select to authenticated
  using (shop_id = my_shop() and my_role() in ('owner', 'admin'));
drop policy if exists p_products_ins on public.products;
create policy p_products_ins on public.products for insert to authenticated
  with check (shop_id = my_shop() and my_role() in ('owner', 'admin') and shop_ok());
drop policy if exists p_products_upd on public.products;
create policy p_products_upd on public.products for update to authenticated
  using (shop_id = my_shop() and my_role() in ('owner', 'admin') and shop_ok())
  with check (shop_id = my_shop() and my_role() in ('owner', 'admin') and shop_ok());
drop policy if exists p_products_del on public.products;
create policy p_products_del on public.products for delete to authenticated
  using (shop_id = my_shop() and my_role() in ('owner', 'admin') and shop_ok());

-- Cheklar faqat make_sale() orqali yoziladi; egasi hammasini, admin faqat o'zinikini ko'radi
drop policy if exists p_sales_sel on public.sales;
create policy p_sales_sel on public.sales for select to authenticated
  using (shop_id = my_shop() and (my_role() = 'owner' or created_by = auth.uid()));
drop policy if exists p_items_sel on public.sale_items;
create policy p_items_sel on public.sale_items for select to authenticated
  using (shop_id = my_shop() and exists (select 1 from public.sales s where s.id = sale_items.sale_id));

revoke all on public.shops, public.profiles, public.products, public.sales, public.sale_items from anon, authenticated;
grant select on public.profiles, public.sales, public.sale_items to authenticated;
grant select, insert, update, delete on public.products to authenticated;

-- ---------- ILOVA FUNKSIYALARI ----------
-- Profilni olish (yo'q bo'lsa yaratadi)
create or replace function public.ensure_profile()
returns table(id uuid, email text, shop_id uuid, role text)
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Avval tizimga kiring'; end if;
  insert into profiles(id, email) values (auth.uid(), (select u.email from auth.users u where u.id = auth.uid()))
    on conflict on constraint profiles_pkey do nothing;
  return query select p.id, p.email, p.shop_id, p.role from profiles p where p.id = auth.uid();
end $$;

-- Yangi do'kon ochish (ro'yxatdan o'tgan odam egasi bo'ladi)
create or replace function public.create_shop(p_name text, p_phone text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_shop uuid;
begin
  if auth.uid() is null then raise exception 'Avval tizimga kiring'; end if;
  perform 1 from profiles where id = auth.uid();
  if not found then raise exception 'Profil topilmadi, qayta kiring'; end if;
  if (select shop_id from profiles where id = auth.uid()) is not null then
    raise exception 'Siz allaqachon do''konga biriktirilgansiz';
  end if;
  if length(trim(coalesce(p_name, ''))) < 2 then raise exception 'Do''kon nomini kiriting'; end if;
  insert into shops(name, phone) values (trim(p_name), nullif(trim(coalesce(p_phone, '')), '')) returning shops.id into v_shop;
  update profiles set shop_id = v_shop, role = 'owner' where profiles.id = auth.uid();
  return v_shop;
end $$;

-- Xodim sifatida kod bilan qo'shilish (egasi tasdiqlaguncha "pending")
create or replace function public.join_shop(p_code text)
returns void language plpgsql security definer set search_path = public as $$
declare v_shop uuid;
begin
  if auth.uid() is null then raise exception 'Avval tizimga kiring'; end if;
  select s.id into v_shop from shops s where s.code = upper(trim(coalesce(p_code, '')));
  if not found then raise exception 'Kod noto''g''ri'; end if;
  update profiles set shop_id = v_shop, role = 'pending' where profiles.id = auth.uid() and profiles.shop_id is null;
  if not found then raise exception 'Siz allaqachon do''konga biriktirilgansiz'; end if;
end $$;

-- Noto'g'ri kod kiritgan (hali tasdiqlanmagan) xodim chiqib ketishi
create or replace function public.leave_shop()
returns void language plpgsql security definer set search_path = public as $$
begin
  update profiles set shop_id = null, role = 'none' where profiles.id = auth.uid() and profiles.role = 'pending';
end $$;

-- Do'kon ma'lumoti va obuna holati (kodni faqat egasi ko'radi)
create or replace function public.shop_info()
returns table(id uuid, name text, code text, paid_until date, days_left int, active boolean, role text)
language sql security definer stable set search_path = public as $$
  select s.id, s.name, case when p.role = 'owner' then s.code end, s.paid_until,
         (s.paid_until - current_date)::int, (s.paid_until >= current_date), p.role
  from profiles p join shops s on s.id = p.shop_id
  where p.id = auth.uid()
$$;

create or replace function public.set_shop_name(p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if coalesce(my_role(), '') <> 'owner' then raise exception 'Faqat egasi'; end if;
  if length(trim(coalesce(p_name, ''))) < 2 then raise exception 'Do''kon nomini kiriting'; end if;
  update shops set name = trim(p_name) where shops.id = my_shop();
end $$;

-- Egasi xodimni tasdiqlaydi yoki bloklaydi
create or replace function public.set_member_role(p_user uuid, p_role text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if coalesce(my_role(), '') <> 'owner' then raise exception 'Faqat egasi'; end if;
  if p_role not in ('admin', 'pending') then raise exception 'Rol noto''g''ri'; end if;
  update profiles set role = p_role
   where profiles.id = p_user and profiles.shop_id = my_shop() and profiles.role in ('admin', 'pending');
  if not found then raise exception 'Xodim topilmadi'; end if;
end $$;

-- Sotuv: chek + tarkib + ombor kamayishi bitta amalda.
-- Bir xil p_client qayta kelsa, ikki marta yozilmaydi (oflayn navbat uchun).
create or replace function public.make_sale(p_client uuid, p_items jsonb, p_at timestamptz default now())
returns bigint language plpgsql security definer set search_path = public as $$
declare v_shop uuid := my_shop(); sid bigint; tot numeric; it jsonb;
begin
  if coalesce(my_role(), '') not in ('owner', 'admin') then raise exception 'Ruxsat yo''q'; end if;
  select s.id into sid from sales s where s.shop_id = v_shop and s.client_id = p_client;
  if found then return sid; end if;
  if not shop_ok() then raise exception 'Obuna muddati tugagan'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Chek bo''sh';
  end if;
  if exists (select 1 from jsonb_array_elements(p_items) x
             where coalesce(x->>'barcode', '') = '' or (x->>'qty')::numeric <= 0 or (x->>'price')::numeric < 0) then
    raise exception 'Chek ma''lumoti noto''g''ri';
  end if;
  select coalesce(sum((x->>'qty')::numeric * (x->>'price')::numeric), 0) into tot from jsonb_array_elements(p_items) x;
  insert into sales(shop_id, client_id, total, created_at)
    values (v_shop, p_client, tot, least(coalesce(p_at, now()), now())) returning sales.id into sid;
  for it in select value from jsonb_array_elements(p_items) loop
    insert into sale_items(sale_id, shop_id, barcode, name, qty, price)
      values (sid, v_shop, it->>'barcode', it->>'name', (it->>'qty')::numeric, (it->>'price')::numeric);
    update products set stock = stock - (it->>'qty')::numeric
     where products.shop_id = v_shop and products.barcode = it->>'barcode';
  end loop;
  return sid;
end $$;

-- Chekni bekor qilish (faqat egasi): mahsulotlar omborga qaytadi
create or replace function public.cancel_sale(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
declare v_shop uuid := my_shop(); v_status text;
begin
  if coalesce(my_role(), '') <> 'owner' then raise exception 'Faqat egasi bekor qila oladi'; end if;
  select s.status into v_status from sales s where s.id = p_id and s.shop_id = v_shop;
  if not found then raise exception 'Chek topilmadi'; end if;
  if v_status <> 'done' then return; end if;
  update products p set stock = p.stock + a.q
    from (select i.barcode, sum(i.qty) q from sale_items i where i.sale_id = p_id group by i.barcode) a
   where p.shop_id = v_shop and p.barcode = a.barcode;
  update sales set status = 'canceled', canceled_at = now(), canceled_by = auth.uid() where sales.id = p_id;
end $$;

-- Kunlik savdo (faqat egasi), Toshkent vaqti bilan
create or replace function public.daily_totals(p_from timestamptz)
returns table(day date, cnt bigint, total numeric)
language plpgsql security definer stable set search_path = public as $$
declare v_shop uuid := my_shop();
begin
  if coalesce(my_role(), '') <> 'owner' then raise exception 'Faqat egasi'; end if;
  return query
    select (s.created_at at time zone 'Asia/Tashkent')::date, count(*), coalesce(sum(s.total), 0)
    from sales s
    where s.shop_id = v_shop and s.status = 'done' and s.created_at >= p_from
    group by 1 order by 1;
end $$;

-- Eng ko'p sotilgan mahsulotlar (faqat egasi)
create or replace function public.top_products(p_from timestamptz, p_to timestamptz)
returns table(out_barcode text, out_name text, out_qty numeric, out_revenue numeric)
language plpgsql security definer stable set search_path = public as $$
declare v_shop uuid := my_shop();
begin
  if coalesce(my_role(), '') <> 'owner' then raise exception 'Faqat egasi'; end if;
  return query
    select i.barcode, max(i.name), sum(i.qty), sum(i.qty * i.price)
    from sale_items i join sales s on s.id = i.sale_id
    where s.shop_id = v_shop and s.status = 'done' and s.created_at >= p_from and s.created_at < p_to
    group by i.barcode order by sum(i.qty) desc limit 50;
end $$;

-- SOTUVCHI UCHUN: obunani uzaytirish. SQL Editor'da:  select extend_shop('ABCD1234', 30);
-- (ilovadan chaqirib bo'lmaydi, faqat siz bajarasiz)
create or replace function public.extend_shop(p_code text, p_days int default 30)
returns date language plpgsql security definer set search_path = public as $$
declare v_until date;
begin
  update shops set paid_until = greatest(shops.paid_until, current_date) + p_days
   where shops.code = upper(trim(p_code)) returning shops.paid_until into v_until;
  if not found then raise exception 'Bunday kodli do''kon yo''q'; end if;
  return v_until;
end $$;

-- ---------- RUXSATLAR ----------
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function
  public.my_shop(), public.my_role(), public.shop_ok(),
  public.ensure_profile(), public.create_shop(text, text), public.join_shop(text), public.leave_shop(),
  public.shop_info(), public.set_shop_name(text), public.set_member_role(uuid, text),
  public.make_sale(uuid, jsonb, timestamptz), public.cancel_sale(bigint),
  public.daily_totals(timestamptz), public.top_products(timestamptz, timestamptz)
to authenticated;
