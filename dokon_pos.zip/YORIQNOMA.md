# Do'kon POS — o'rnatish va sotish yo'riqnomasi

## 1. Bir martalik o'rnatish (sotuvchi uchun, ~15 daqiqa)
1. **Supabase** → SQL Editor:
   - Agar eski (bitta do'kon) versiya o'rnatilgan va ma'lumot kerak BO'LMASA: avval `reset_eski.sql` ni RUN qiling.
   - Keyin `setup.sql` ni RUN qiling (xavfsiz, qayta ishga tushirsa bo'ladi).
2. **Authentication → Providers → Email**: `Confirm email` ni **o'chiring** (aks holda mijoz ro'yxatdan o'tgach xat kutadi).
3. **Authentication → URL Configuration**: `Site URL` ga Render manzilingizni yozing (parolni tiklash havolasi shu yerga qaytadi).
4. `index.html` dagi `SUPPORT` (telefon va narx) o'rnatilgan: +998 20 001 25 60, 49 000 so'm / 30 kun (obuna tugaganda mijozga shu raqam ko'rinadi).
5. Fayllarni GitHub'ga yuklang (`index.html`, `sw.js`, `manifest.webmanifest`, `icon-*.png`) → Render Static Site (publish directory: `.`).
6. **Secret key** hech qayerga (index.html, Render, chat) yozilmaydi. Faqat publishable key ishlatiladi. Chatga tashlangan kalitni Supabase'da albatta yangilang (rotate).

## 2. Yangi mijoz ulash
1. Mijoz ilovani ochadi → ro'yxatdan o'tadi → **"Yangi do'kon ochish"** (nom, telefon). 14 kun bepul.
2. Xodimlar ro'yxatdan o'tib **"Xodim sifatida qo'shilish"** da do'kon kodini kiritadi; egasi Sozlama → Xodimlar'da tasdiqlaydi.
3. Mahsulotlar: Sozlama → **CSV import** (namuna: `mahsulotlar_namuna.csv`). Excel'da shtrix-kod ustunini **Matn (Text)** qiling, aks holda 4.78E+12 bo'lib buziladi. Yoki skaner bilan bittalab qo'shing (nomi avtomatik chiqadi).

## 3. Obunani boshqarish (faqat siz, SQL Editor'da)
```sql
-- 30 kun uzaytirish (do'kon kodi Sozlama'da ko'rinadi)
select extend_shop('ABCD1234', 30);

-- Barcha do'konlar
select name, phone, code, paid_until, paid_until - current_date as kun_qoldi
from shops order by paid_until;
```
Muddat tugasa: sotuv to'xtaydi, lekin ma'lumotlarni ko'rish va yuklab olish ishlayveradi; navbatdagi (oflayn) cheklar yo'qolmaydi.

## 4. Monoblok + printer + skaner
- Skaner USB "klaviatura" rejimida bo'lsin: qidiruv maydoniga yozadi va Enter bosadi — qo'shimcha sozlama kerak emas.
- Printer: Windows'da chek printerini **standart (default)** qiling. Chrome'ni jim chop etish bilan oching:
  `chrome.exe --kiosk --kiosk-printing --app=https://SIZNING-SAYT.onrender.com`
- Chek kengligi (80mm/58mm) Sozlama'da tanlanadi.
- Birinchi ochilishda internet kerak; keyin internet uzilsa ham sotuv davom etadi va ulanganda avtomatik yuboriladi.

## 5. Sotishdan oldin e'tibor bering
- Supabase **Pro** tarifi tavsiya (avtomatik zaxira nusxa, cheklovlarsiz ishlash). Bepul tarif sust faoliyatda to'xtab qolishi mumkin.
- Parol tiklash xatlari uchun o'z SMTP'ingizni ulang (Supabase standart pochtasi juda cheklangan).
- Ilova soliq/fiskal chek (OFD) emas — mijozga shuni shartnomada yozing. Kerak bo'lsa alohida fiskal modul talab qilinadi.
- Mijoz bilan oddiy xizmat shartnomasi tuzing (narx, qo'llab-quvvatlash, ma'lumot egasi — mijoz).
